Las páginas del proyecto se pueden ver en los siguientes enlaces  

Tutorial media 

https://mariomorales.xyz/tutorial/index.html

Tutorial Mediana 

https://mariomorales.xyz/tutorial/mediana.html
